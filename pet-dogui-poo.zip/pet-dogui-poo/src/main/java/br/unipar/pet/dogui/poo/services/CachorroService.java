
package br.unipar.pet.dogui.poo.services;

import br.unipar.pet.dogui.poo.domain.Cachorro;
import br.unipar.pet.dogui.poo.exceptions.NegocioException;
import br.unipar.pet.dogui.poo.respositories.CachorroRepository;
import java.sql.SQLException;
import java.util.ArrayList;

public class CachorroService {
    
    public Cachorro insert(Cachorro cachorro) throws SQLException, 
                                                        NegocioException{
        
        validate(cachorro);
        
        CachorroRepository cachorroRepository = new CachorroRepository();
        cachorro = cachorroRepository.insert(cachorro);
        
        return cachorro;
    } 
    
    
    public Cachorro edit(Cachorro cachorro) throws SQLException, 
                                                        NegocioException {
        
        validate(cachorro);
        validateUpdate(cachorro);
        
        CachorroRepository cachorroRepository = new CachorroRepository();
        cachorro = cachorroRepository.update(cachorro);
        
        return cachorro;
        
    }
    
    public Cachorro findById(int id) throws SQLException {
        
        CachorroRepository cachorroRepository = new CachorroRepository();
        Cachorro cachorro = cachorroRepository.findById(id);
        
        return cachorro;
        
    }
    
    public ArrayList<Cachorro> findAll() throws SQLException {
        
        CachorroRepository cachorroRepository = new CachorroRepository();
        ArrayList<Cachorro> resultado = cachorroRepository.findAll();
        
        return resultado;
    }
    
    private void validate(Cachorro cachorro) throws NegocioException {
        if (cachorro.getNome() == null) {
            throw new NegocioException("O nome é obrigatório!");
        }
        if (cachorro.getNome().length() > 60) {
            throw new NegocioException("O nome não deve ter mais"
                    + " que 60 caracteres");
        }
        if (cachorro.getTamanho() < 0 || cachorro.getTamanho() > 99.99) {
            throw new NegocioException
                    ("O cachorro deve ser maior que 0 e menor que 99.99");
        }
        if (cachorro.getTamanho() == null) {
            throw new NegocioException
                    ("O tamanho do cachorro deve ser informado.");
        }    
        
        if (cachorro.getDtNascimento() == null) {
            throw new NegocioException
                    ("A data de nascimento do cachorro deve ser informada.");
        }
        if (cachorro.getRaca() == null) {
            throw new NegocioException
                    ("A raça do cachorro deve ser informada.");
        }
        if (cachorro.getPelagem() == null) {
            throw new NegocioException
                    ("A pelagem do cachorro deve ser informada.");
        }
        if (cachorro.getCor() == null) {
           throw new NegocioException("A cor do cachorro deve ser informada.");
        }
 
    }
    
    private void validateUpdate(Cachorro cachorro) throws NegocioException {
        if (cachorro.getId() == 0) {
            throw new NegocioException("Informe um código válido "
                    + "para atualização do cachorro!");
        }
    }
    
    public void delete(int id) throws SQLException {
        CachorroRepository cachorroRepository = new CachorroRepository();
        cachorroRepository.delete(id);
    }   
}