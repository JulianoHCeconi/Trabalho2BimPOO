
package br.unipar.pet.dogui.poo.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter //Annotations 
@ToString // ToString
@AllArgsConstructor //Construtor com todos os argumentos
@NoArgsConstructor //Contrutor vazio
public class Cor {
    private int id;
    private String descricao;
}
