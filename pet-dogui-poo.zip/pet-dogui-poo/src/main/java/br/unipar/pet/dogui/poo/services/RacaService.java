
package br.unipar.pet.dogui.poo.services;

import br.unipar.pet.dogui.poo.domain.Raca;
import br.unipar.pet.dogui.poo.exceptions.NegocioException;
import br.unipar.pet.dogui.poo.respositories.RacaRepository;
import java.sql.SQLException;
import java.util.ArrayList;

public class RacaService {
    
    public Raca insert(Raca raca) throws SQLException, NegocioException{
        
        validate(raca);
        
        RacaRepository racaRepository = new RacaRepository();
        raca = racaRepository.insert(raca);
        
        return raca;
    } 
    
    
    public Raca edit(Raca raca) throws SQLException, NegocioException {
        
        validate(raca);
        validateUpdate(raca);
        
        RacaRepository racaRepository = new RacaRepository();
        raca = racaRepository.update(raca);
        
        return raca;
        
    }
    
    public Raca findById(int id) throws SQLException {
        
        RacaRepository racaRepository = new RacaRepository();
        Raca raca = racaRepository.findById(id);
        
        return raca;
        
    }
    
    public ArrayList<Raca> findAll() throws SQLException {
        
        RacaRepository racaRepository = new RacaRepository();
        ArrayList<Raca> res = racaRepository.findAll();
        
        return res;
    }
    
    private void validate(Raca raca) throws NegocioException {
        if (raca.getDescricao() == null) {
            throw new NegocioException("A descrição da raça deve ser "
                    + "Informada.");
        }
        if (raca.getDescricao().isBlank()) {
            throw new NegocioException("A descrição da raça "
                    + "deve ser Informada.");
        }
        if (raca.getDescricao().length() <= 4) {
            throw new NegocioException("A descrição da raça "
                    + "deve possuir 4 "
                    + "ou mais caracteres.");
        }
        if (raca.getDescricao().length() > 60) {
            throw new NegocioException("A descrição da raça "
                    + "não deve possuir "
                    + "mais do que 60 caracteres");
        }
    }
    
    private void validateUpdate(Raca raca) throws NegocioException {
        if (raca.getId() == 0) {
            throw new NegocioException("Informe um Código Válido "
                    + "para atualização da raça!");
        }
    }
    
    public void delete(int id) throws SQLException {
        RacaRepository racaRepository = new RacaRepository();
        racaRepository.delete(id);
    }
    
}
