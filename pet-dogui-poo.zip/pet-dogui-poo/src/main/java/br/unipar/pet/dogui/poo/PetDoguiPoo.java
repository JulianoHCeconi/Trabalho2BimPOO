package br.unipar.pet.dogui.poo;

import br.unipar.pet.dogui.poo.domain.Cachorro;
import br.unipar.pet.dogui.poo.domain.Cor;
import br.unipar.pet.dogui.poo.domain.Pelagem;
import br.unipar.pet.dogui.poo.domain.Raca;
import br.unipar.pet.dogui.poo.exceptions.NegocioException;
import br.unipar.pet.dogui.poo.services.CachorroService;
import br.unipar.pet.dogui.poo.services.CorService;
import br.unipar.pet.dogui.poo.services.PelagemService;
import br.unipar.pet.dogui.poo.services.RacaService;
import java.sql.SQLException;
import java.util.ArrayList;

public class PetDoguiPoo {

    public static void main(String[] args) {
        
        try {
            
            // Cor
            CorService corService = new CorService();
            
            Cor c = new Cor();
            c.setDescricao("Preto");
            corService.insert(c);
            
            ArrayList<Cor> cores = corService.findAll();
            System.out.println("Cores: ");
            for (Cor cor : cores) {
                System.out.println(cor.getDescricao());
            }
            
            // Pelagem
            PelagemService pelagemService = new PelagemService();
            
            Pelagem p = new Pelagem();
            p.setDescricao("Pelagem encaracolada");
            pelagemService.insert(p);
            
            ArrayList<Pelagem> pelagens = pelagemService.findAll();
            System.out.println("\nPelagens: ");
            for (Pelagem pelagem : pelagens) {
                System.out.println(pelagem.getDescricao());
            }
            
            // Raça
            RacaService racaService = new RacaService();
            
            Raca r = new Raca();
            r.setDescricao("Pitbull");
            racaService.insert(r);
            
            ArrayList<Raca> racas = racaService.findAll();
            System.out.println("\nRaças: ");
            for (Raca raca : racas) {
                System.out.println(raca.getDescricao());
            }
            
            // Cachorro
            CachorroService cachorroService = new CachorroService();
            
            Cachorro dog = new Cachorro();
            dog.setNome("Thor");
            dog.setTamanho(0.9);
            dog.setStPerfume(false);
            dog.setDtNascimento(java.sql.Date.valueOf("2020-03-24"));
            dog.setIdRaca(r.getId());
            dog.setIdPelagem(p.getId());
            dog.setIdCor(c.getId());
            dog = cachorroService.insert(dog);
            
            System.out.println("\nCachorro inserido com sucesso: " + dog);
            
        } catch (SQLException ex) {
            System.out.println
        ("Ops, algo deu errado com o banco de dados:\n" + ex.getMessage());
        } catch (NegocioException ex) {
            System.out.println("Erro de negócio:\n" + ex.getMessage());
        } catch (Exception ex) {    
            System.out.println
        ("Ops, algo deu errado contate o suporte:\n" + ex.getMessage());
        }
        
    }
}