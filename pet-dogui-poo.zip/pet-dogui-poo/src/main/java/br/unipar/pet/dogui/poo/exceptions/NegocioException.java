
package br.unipar.pet.dogui.poo.exceptions;

public class NegocioException extends Exception {
    
    public NegocioException(String mensagem){
        super(mensagem);
    }
    
}
